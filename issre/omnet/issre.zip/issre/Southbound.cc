 #include <string.h>
#include <string>
#include <omnetpp.h>
#include <sstream>
#include <random>
    using namespace omnetpp;

    /**
     * Derive the Txc1 class from cSimpleModule. In the Tictoc1 network,
     * both the `tic' and `toc' modules are Txc1 objects, created by OMNeT++
     * at the beginning of the simulation.
     */
    class Southbound : public cSimpleModule
    {
    public:
        Southbound();
    private:
        cMessage*  TRIGGER;
        cMessage*  TRANSMIT;
        cMessage*  MIXING;
        //cMessage*  PUSH;

        int WL ;
        int PH ;
        int TM;
        const int PHR =7;
        bool sensorPH ;
        bool sensorWL ;
        bool sensorTM ;

        bool readPH ;
        bool readWL ;
        bool readTM ;

        int pld; //generated payload
        double lambda;  // Rate parameter for the exponential distribution
        std::default_random_engine generator;
        std::exponential_distribution<double> distribution;
        std::vector<std::string> extractSubstrings(const std::string& inputString);
        void transmit(int pld);
        void activatePump ();
        int function_down(int ph, int tm, int wl);
        int function_up(int ph, int tm, int wl);
   protected:
        // The following redefined virtual function holds the algorithm.
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;

    };

    // The module class needs to be registered with OMNeT++
    Define_Module(Southbound);


    Southbound::Southbound() {
        lambda = 0.5;
    }

    void Southbound::initialize()
    {
        TRIGGER = new cMessage();
        double interval = distribution(generator, std::exponential_distribution<double>::param_type(lambda));
        scheduleAt(simTime() + interval, TRIGGER);
    }
    void Southbound::handleMessage(cMessage *msg)
    {
        EV << "Received " << msg->getName()  << endl;
        std::string s = msg->getName();
        bool isFound = s.find("TRANSMIT") != std::string::npos;
        if(isFound){

            sensorPH = s.find("PH") != std::string::npos;
            sensorWL = s.find("WL") != std::string::npos;
            sensorTM = s.find("TM") != std::string::npos;

            std::vector<std::string> extractedSubstrings = extractSubstrings( msg->getName());
            std::string PLD = extractedSubstrings[2];
            int pld = std::stoi(PLD);
            if(sensorPH){
                readPH=true;
                PH=pld;
            }else{
                if(sensorWL){
                    readWL=true;
                    WL=pld;
                }
                    else{
                        if(sensorTM){
                            readTM=true;
                            TM=pld;
                        }
                    }

                }
        }
                if(readPH && readWL && readTM){
                    readPH=false;
                    readWL=false;
                    readTM=false;
                                   if(PH> PHR){
                                       pld= function_down(PH,TM,WL);
                                   }else{
                                       pld= function_up(PH,TM,WL);
                                   }
                                   transmit(pld);

                                   activatePump();
                  }


        TRIGGER = new cMessage();
        double interval = distribution(generator, std::exponential_distribution<double>::param_type(lambda));
        scheduleAt(simTime() + interval, TRIGGER);

    }


    void Southbound::transmit(int pld)
    {
        std::string result = std::string("TRANSMIT/PHC/") +std::string(std::to_string(pld));
        TRANSMIT = new cMessage(result.c_str());
        send(TRANSMIT, "PhcData"); // send out the message
    }

    void Southbound::activatePump()
    {
        std::string result = std::string("MIXING") ;
        MIXING = new cMessage(result.c_str());
        //simtime_t delay = 100; //
        //scheduleAt(simTime() + delay, MIXING);
        sendDelayed(MIXING, 100,"MixingData"); // send out the message
    }
    int Southbound::function_down(int ph, int tm, int wl){
        return ph-1;
    }
    int Southbound::function_up(int ph, int tm, int wl){
        return ph+1;
    }

    std::vector<std::string> Southbound::extractSubstrings(const std::string& inputString) {
        std::vector<std::string> substrings;
        std::istringstream iss(inputString);
        std::string substring;

        while (std::getline(iss, substring, '/')) {
            substrings.push_back(substring);
        }

        return substrings;
    }
