#include <string.h>
#include <string>
#include <omnetpp.h>
#include <sstream>
#include <random>
    #include <omnetpp.h>

    using namespace omnetpp;

    using namespace std;

    class WaterLevel : public cSimpleModule
    {
    public:
        WaterLevel();
    private:
        cMessage*  TRIGGER;
        cMessage*  TRANSMIT;
        int pld; //generated payload
        double lambda;  // Rate parameter for the exponential distribution
        std::default_random_engine generator;
        std::exponential_distribution<double> distribution;
        std::vector<std::string> extractSubstrings(const std::string& inputString);
        void transmit(int pld);
protected:
        // The following redefined virtual function holds the algorithm.
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
    };


    Define_Module(WaterLevel);


    WaterLevel::WaterLevel() {
        lambda = 0.5;
    }

    void WaterLevel::initialize()
    {
        TRIGGER = new cMessage();
        double interval = distribution(generator, std::exponential_distribution<double>::param_type(lambda));
        scheduleAt(simTime() + interval, TRIGGER);
    }
    void WaterLevel::handleMessage(cMessage *msg)
    {
        pld=intuniform(0, 100);
        transmit(pld);

        TRIGGER = new cMessage();
        double interval = distribution(generator, std::exponential_distribution<double>::param_type(lambda));
        scheduleAt(simTime() + interval, TRIGGER);

    }

    void WaterLevel::transmit(int pld)
    {
        std::string result = std::string("TRANSMIT/WL/") + std::string(std::to_string(pld));
        TRANSMIT = new cMessage(result.c_str());
        send(TRANSMIT, "data"); // send out the message
    }
